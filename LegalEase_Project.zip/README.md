# LegalEase – AI-Powered Legal Document Generator

A BCA mini/full-stack project for generating structured legal-document drafts from user-provided information.

## Tech Stack
- Frontend: HTML5, CSS3, JavaScript
- Backend: Python Flask
- Database: SQLite
- Document output: TXT
- Architecture: Server-rendered web application

## Main Modules
1. User registration and login
2. Legal document template selection
3. Dynamic document-generation forms
4. Draft generation
5. Preview
6. Download
7. Document history/dashboard

## Included Templates
- Rental Agreement
- Non-Disclosure Agreement (NDA)
- Employment Agreement
- Affidavit
- Authorization Letter

## Run on Windows
1. Install Python 3.10+.
2. Open Command Prompt in this project folder.
3. Create a virtual environment:
   `python -m venv venv`
4. Activate it:
   `venv\Scripts\activate`
5. Install dependencies:
   `pip install -r requirements.txt`
6. Start:
   `python app.py`
7. Open:
   `http://127.0.0.1:5000`

## Demo Login
Create a new account from the Register page. This demo stores passwords as plain text for simplicity; for a production system, use password hashing, CSRF protection, secure sessions, and a proper authentication service.

## Project Disclaimer
LegalEase is an educational document-drafting project. Generated text is not legal advice and should be reviewed by a qualified legal professional before being signed, filed, or relied upon.

## Suggested Future Enhancements
- OpenAI/LLM API integration
- PDF and DOCX export
- Digital signatures
- Email delivery
- Admin dashboard
- Advanced Indian-law templates
- Multilingual Tamil/English generation
- Secure password hashing and role-based access
