from flask import Flask, render_template, request, redirect, url_for, session, flash, send_from_directory
import sqlite3
from pathlib import Path
from datetime import datetime
import re

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "legalese.db"
GENERATED_DIR = BASE_DIR / "app" / "generated"

app = Flask(__name__, template_folder="app/templates", static_folder="app/static")
app.secret_key = "legalese-development-secret-key"
GENERATED_DIR.mkdir(parents=True, exist_ok=True)

TEMPLATES = {
    "rental": {
        "name": "Rental Agreement",
        "description": "Basic residential rental agreement with rent, deposit and term details.",
        "fields": ["landlord", "tenant", "property_address", "monthly_rent", "deposit", "start_date", "duration"]
    },
    "nda": {
        "name": "Non-Disclosure Agreement",
        "description": "Simple mutual confidentiality agreement for two parties.",
        "fields": ["party_a", "party_b", "purpose", "start_date", "duration"]
    },
    "employment": {
        "name": "Employment Agreement",
        "description": "Basic employment agreement covering role, compensation and start date.",
        "fields": ["employer", "employee", "role", "salary", "start_date", "work_location", "notice_period"]
    },
    "affidavit": {
        "name": "Affidavit",
        "description": "General-purpose affidavit structure for a declarant and stated facts.",
        "fields": ["declarant", "address", "subject", "facts", "place", "date"]
    },
    "authorization": {
        "name": "Authorization Letter",
        "description": "Letter authorizing another person to act on your behalf for a stated purpose.",
        "fields": ["authorizer", "authorized_person", "purpose", "valid_from", "valid_until", "place", "date"]
    },
}

FIELD_LABELS = {
    "landlord": "Landlord Name", "tenant": "Tenant Name", "property_address": "Property Address",
    "monthly_rent": "Monthly Rent", "deposit": "Security Deposit", "start_date": "Start Date",
    "duration": "Agreement Duration", "party_a": "Party A", "party_b": "Party B",
    "purpose": "Purpose", "employer": "Employer Name", "employee": "Employee Name",
    "role": "Job Role", "salary": "Salary / Compensation", "work_location": "Work Location",
    "notice_period": "Notice Period", "declarant": "Declarant Name", "address": "Address",
    "subject": "Subject / Matter", "facts": "Facts / Statements", "place": "Place",
    "date": "Date", "authorized_person": "Authorized Person", "valid_from": "Valid From",
    "valid_until": "Valid Until"
}

def init_db():
    con = sqlite3.connect(DB_PATH)
    con.execute("""CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL
    )""")
    con.execute("""CREATE TABLE IF NOT EXISTS documents (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        template TEXT NOT NULL,
        filename TEXT NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id)
    )""")
    con.commit()
    con.close()

def generate_document(template, data):
    today = data.get("date") or datetime.now().strftime("%d %B %Y")
    if template == "rental":
        return f"""RENTAL AGREEMENT

This Rental Agreement is made on {today} between {data.get('landlord','')} ("Landlord") and {data.get('tenant','')} ("Tenant").

1. PROPERTY
The property covered by this agreement is: {data.get('property_address','')}.

2. RENT
The Tenant agrees to pay a monthly rent of {data.get('monthly_rent','')}.

3. SECURITY DEPOSIT
The security deposit is {data.get('deposit','')}.

4. TERM
The tenancy begins on {data.get('start_date','')} and continues for {data.get('duration','')}.

5. GENERAL TERMS
The parties agree to comply with applicable laws and the mutually agreed terms concerning use, maintenance, payment and termination.

SIGNATURES

Landlord: __________________________
Tenant: ____________________________

DISCLAIMER: This generated document is a general drafting aid and should be reviewed by a qualified legal professional before use."""
    if template == "nda":
        return f"""NON-DISCLOSURE AGREEMENT

This Non-Disclosure Agreement is entered into on {today} by and between {data.get('party_a','')} and {data.get('party_b','')}.

1. PURPOSE
The parties intend to share information for the following purpose:
{data.get('purpose','')}

2. CONFIDENTIAL INFORMATION
Confidential information may include business, technical, financial or other non-public information shared for the stated purpose.

3. CONFIDENTIALITY
Each party agrees to use reasonable care to protect confidential information and to use it only for the stated purpose, subject to applicable law.

4. TERM
This agreement begins on {data.get('start_date','')} and remains effective for {data.get('duration','')}.

SIGNATURES

Party A: ___________________________
Party B: ___________________________

DISCLAIMER: This generated document is a general drafting aid and should be reviewed by a qualified legal professional before use."""
    if template == "employment":
        return f"""EMPLOYMENT AGREEMENT

This Employment Agreement is made on {today} between {data.get('employer','')} ("Employer") and {data.get('employee','')} ("Employee").

1. POSITION
The Employee will serve as: {data.get('role','')}.

2. COMPENSATION
The agreed salary / compensation is: {data.get('salary','')}.

3. START DATE
Employment begins on: {data.get('start_date','')}.

4. WORK LOCATION
Primary work location: {data.get('work_location','')}.

5. NOTICE
The applicable notice period is: {data.get('notice_period','')}.

6. GENERAL
The parties agree to comply with applicable employment laws and organizational policies.

SIGNATURES

Employer: __________________________
Employee: __________________________

DISCLAIMER: This generated document is a general drafting aid and should be reviewed by a qualified legal professional before use."""
    if template == "affidavit":
        return f"""AFFIDAVIT

I, {data.get('declarant','')}, residing at {data.get('address','')}, do hereby solemnly affirm and state as follows:

1. SUBJECT
{data.get('subject','')}

2. STATEMENTS OF FACT
{data.get('facts','')}

I declare that the statements above are made in good faith and to the best of my knowledge and belief.

Place: {data.get('place','')}
Date: {today}

DEPONENT

Signature: __________________________

DISCLAIMER: This generated document is a general drafting aid and should be reviewed by a qualified legal professional before use."""
    if template == "authorization":
        return f"""AUTHORIZATION LETTER

Date: {today}
Place: {data.get('place','')}

To Whom It May Concern,

I, {data.get('authorizer','')}, hereby authorize {data.get('authorized_person','')} to act on my behalf for the following purpose:

{data.get('purpose','')}

This authorization is valid from {data.get('valid_from','')} until {data.get('valid_until','')}, subject to applicable law and any limitations stated by the relevant authority.

Authorizer Signature: __________________________
Authorized Person Signature: ____________________

DISCLAIMER: This generated document is a general drafting aid and should be reviewed by a qualified legal professional before use."""
    return "Template not found."

@app.route("/")
def index():
    return render_template("index.html", templates=TEMPLATES)

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name, email, password = request.form["name"].strip(), request.form["email"].strip().lower(), request.form["password"]
        if not name or not email or not password:
            flash("Please complete all fields.")
            return redirect(url_for("register"))
        try:
            con = sqlite3.connect(DB_PATH)
            con.execute("INSERT INTO users(name,email,password) VALUES(?,?,?)", (name,email,password))
            con.commit()
            con.close()
            flash("Account created. Please sign in.")
            return redirect(url_for("login"))
        except sqlite3.IntegrityError:
            flash("An account with that email already exists.")
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email, password = request.form["email"].strip().lower(), request.form["password"]
        con = sqlite3.connect(DB_PATH)
        user = con.execute("SELECT id,name,email FROM users WHERE email=? AND password=?", (email,password)).fetchone()
        con.close()
        if user:
            session["user_id"], session["user_name"] = user[0], user[1]
            return redirect(url_for("dashboard"))
        flash("Invalid email or password.")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))

@app.route("/dashboard")
def dashboard():
    if "user_id" not in session:
        return redirect(url_for("login"))
    con = sqlite3.connect(DB_PATH)
    docs = con.execute("SELECT id,title,template,filename,created_at FROM documents WHERE user_id=? ORDER BY id DESC", (session["user_id"],)).fetchall()
    con.close()
    return render_template("dashboard.html", templates=TEMPLATES, docs=docs)

@app.route("/create/<template>", methods=["GET", "POST"])
def create(template):
    if "user_id" not in session:
        return redirect(url_for("login"))
    if template not in TEMPLATES:
        return redirect(url_for("dashboard"))
    meta = TEMPLATES[template]
    if request.method == "POST":
        data = {f: request.form.get(f, "").strip() for f in meta["fields"]}
        content = generate_document(template, data)
        title = meta["name"]
        safe = re.sub(r"[^A-Za-z0-9_-]+", "_", title).strip("_").lower()
        filename = f"{safe}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        (GENERATED_DIR / filename).write_text(content, encoding="utf-8")
        con = sqlite3.connect(DB_PATH)
        con.execute("INSERT INTO documents(user_id,title,template,filename,created_at) VALUES(?,?,?,?,?)",
                    (session["user_id"], title, template, filename, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        con.commit()
        con.close()
        return redirect(url_for("preview", filename=filename))
    return render_template("create.html", template=template, meta=meta, labels=FIELD_LABELS)

@app.route("/preview/<filename>")
def preview(filename):
    if "user_id" not in session:
        return redirect(url_for("login"))
    con = sqlite3.connect(DB_PATH)
    row = con.execute("SELECT title FROM documents WHERE user_id=? AND filename=?", (session["user_id"], filename)).fetchone()
    con.close()
    if not row:
        return redirect(url_for("dashboard"))
    path = GENERATED_DIR / filename
    if not path.exists():
        return redirect(url_for("dashboard"))
    content = path.read_text(encoding="utf-8")
    return render_template("preview.html", title=row[0], content=content, filename=filename)

@app.route("/download/<filename>")
def download(filename):
    if "user_id" not in session:
        return redirect(url_for("login"))
    con = sqlite3.connect(DB_PATH)
    row = con.execute("SELECT id FROM documents WHERE user_id=? AND filename=?", (session["user_id"], filename)).fetchone()
    con.close()
    if not row:
        return redirect(url_for("dashboard"))
    return send_from_directory(GENERATED_DIR, filename, as_attachment=True)

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
